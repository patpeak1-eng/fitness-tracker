import React, { useContext, useState, useEffect } from 'react';
import { WorkoutContext } from '../context/WorkoutContext';
import ExerciseResult from '../components/workout/ExerciseResult';
import TemplateSelector from '../components/workout/TemplateSelector';
import { Play, Plus, Clock, XCircle } from 'lucide-react';
import './TrackWorkout.css';

const TrackWorkout = () => {
    const { activeWorkout, exercises, completeWorkout, cancelWorkout, templates, startWorkoutFromTemplate } = useContext(WorkoutContext);
    const [showSelector, setShowSelector] = useState(false);
    const [elapsedTime, setElapsedTime] = useState(0);

    // Timer Logic
    useEffect(() => {
        let interval;
        if (activeWorkout) {
            // Calculate elapsed seconds since start or default to 0
            const startTime = activeWorkout.startTime ? new Date(activeWorkout.startTime).getTime() : Date.now();

            // Initial set
            setElapsedTime(Math.floor((Date.now() - startTime) / 1000));

            interval = setInterval(() => {
                setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [activeWorkout]);

    // Format MM:SS
    const formatTime = (seconds) => {
        if (!seconds && seconds !== 0) return "--:--";
        const m = Math.floor(seconds / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    };

    if (!activeWorkout) {
        return (
            <div className="track-workout-empty glass-morphism">
                <div className="empty-state">
                    <div className="empty-icon">
                        <Play size={48} />
                    </div>
                    <h2>No Active Session</h2>
                    <p>Select a template to begin your training session.</p>

                    <button
                        onClick={() => setShowSelector(true)}
                        className="primary-btn-large"
                    >
                        START NEW WORKOUT
                    </button>
                </div>

                {showSelector && (
                    <TemplateSelector
                        templates={templates}
                        onSelect={(id) => {
                            startWorkoutFromTemplate(id);
                            setShowSelector(false);
                        }}
                        onClose={() => setShowSelector(false)}
                    />
                )}
            </div>
        );
    }

    return (
        <div className="track-workout-container">
            {/* Active Header */}
            <header className="active-header">
                <div>
                    <span className="status-badge">LIVE SESSION</span>
                    <h1>{activeWorkout.name}</h1>
                </div>
                <div className="active-timer">
                    <Clock size={16} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'middle' }} />
                    {formatTime(elapsedTime)}
                </div>
            </header>

            <div className="workout-stream">
                {activeWorkout.exercises && activeWorkout.exercises.map((item, index) => {
                    // Handle hybrid data (string IDs vs objects)
                    const exId = (typeof item === 'object' && item.exercise) ? item.exercise.id : item;
                    return (
                        <ExerciseResult
                            key={`${exId}-${index}`}
                            exerciseId={exId}
                            exercises={exercises}
                            workoutData={typeof item === 'object' ? item : null}
                        />
                    );
                })}

                {/* Add Exercise Button (Visual Only for now) */}
                <button className="add-exercise-btn">
                    <Plus size={20} />
                    <span>Add Exercise</span>
                </button>

                <button onClick={cancelWorkout} className="cancel-workout-text">
                    Cancel Workout
                </button>
            </div>

            <footer style={{ position: 'fixed', bottom: 0, left: 0, width: '100%', padding: '20px', background: 'linear-gradient(to top, #000 80%, transparent)', zIndex: 10 }}>
                <button
                    onClick={completeWorkout}
                    className="finish-btn"
                    style={{ width: '100%', padding: '15px 0', fontSize: '1.2rem' }}
                >
                    FINISH WORKOUT
                </button>
            </footer>

            {/* Spacer for fixed footer */}
            <div style={{ height: '100px' }}></div>
        </div>
    );
};

export default TrackWorkout;
