import React, { useState } from 'react';
import { Info, MoreHorizontal, Plus, Check } from 'lucide-react';
import './ExerciseResult.css';

const ExerciseResult = ({ exerciseId, exercises, workoutData }) => {
    // CRITICAL: Find the exercise safely
    const safeExercises = exercises || [];
    const exercise = safeExercises.find(ex => ex.id === exerciseId);

    // Default sets state (normally this would sync with context/backend)
    // If workoutData exists and has sets, use them. Otherwise default to 3 empty sets.
    const initialSets = (workoutData && workoutData.sets && workoutData.sets.length > 0)
        ? workoutData.sets
        : [
            { id: 1, weight: '', reps: '', completed: false },
            { id: 2, weight: '', reps: '', completed: false },
            { id: 3, weight: '', reps: '', completed: false }
        ];

    const [sets, setSets] = useState(initialSets);

    const toggleSetComplete = (index) => {
        const newSets = [...sets];
        newSets[index].completed = !newSets[index].completed;
        setSets(newSets);
    };

    // If exercise is missing, show a non-crashing UI
    if (!exercise || exercise.id === 'unknown') {
        return (
            <div className="p-4 border border-red-500 bg-red-500/10 rounded-lg my-2">
                <p className="text-red-500 font-bold">⚠️ Data Mismatch: {exerciseId}</p>
            </div>
        );
    }

    return (
        <div className="exercise-result-card">
            <header className="exercise-header">
                <div className="header-left">
                    <h3>{exercise.name}</h3>
                    <button className="info-btn">
                        <Info size={16} />
                    </button>
                </div>
                <button className="more-options">
                    <MoreHorizontal size={20} />
                </button>
            </header>

            {/* Sets Header */}
            <div className="sets-header">
                <div className="col-set">SET</div>
                <div className="col-weight">KGS</div>
                <div className="col-reps">REPS</div>
                <div className="col-reps">RPE</div>
                <div className="col-check">Done</div>
            </div>

            {/* Sets Rows */}
            <div className="sets-container">
                {sets.map((set, index) => (
                    <div key={index} className={`set-row ${set.completed ? 'completed' : ''}`}>
                        <div className="col-set">{index + 1}</div>
                        <div className="col-weight">
                            <input type="number" placeholder="-" defaultValue={set.weight} />
                        </div>
                        <div className="col-reps">
                            <input type="number" placeholder="-" defaultValue={set.reps} />
                        </div>
                        <div className="col-reps">
                            <input type="number" placeholder="-" />
                        </div>
                        <div className="col-check">
                            <button
                                className={`check-btn ${set.completed ? 'active' : ''}`}
                                onClick={() => toggleSetComplete(index)}
                            >
                                <Check size={20} className={set.completed ? "text-lime-400" : ""} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            <button className="add-set-btn">
                <Plus size={16} style={{ display: 'inline', marginRight: '5px' }} />
                Add Set
            </button>
        </div>
    );
};

export default ExerciseResult;
