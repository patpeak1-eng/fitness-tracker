import React from 'react';
import { LayoutDashboard, Play, TrendingUp, User } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import './BottomNavigation.css';

const BottomNavigation = () => {
    return (
        <nav className="bottom-nav">
            <NavLink to="/" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                <LayoutDashboard size={24} />
                <span className="nav-label">Home</span>
            </NavLink>

            <NavLink to="/track" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                <Play size={24} fill="currentColor" fillOpacity={0.2} /> {/* Distinctive Play Icon */}
                <span className="nav-label">Workout</span>
            </NavLink>

            <NavLink to="/analytics" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                <TrendingUp size={24} />
                <span className="nav-label">Progress</span>
            </NavLink>

            <NavLink to="/profile" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
                <User size={24} />
                <span className="nav-label">Profile</span>
            </NavLink>
        </nav>
    );
};

export default BottomNavigation;
